chrome.runtime.onInstalled.addListener(() => {
    console.log("LinkedIn DM Fetcher Installed!");
});
