(() => {
  console.log("LinkedIn Message Extractor loaded!");
})();
